<?php
    ob_start();
    // include header.php file
    include ('header.php');
?>

<?php

    /*  include banner area  */
        include ('scripts/_banner-area.php');
    /*  include banner area  */

    /*  include top sale section */
        include ('scripts/_top-sale.php');
    /*  include top sale section */

    /*  include special price section  */
         include ('scripts/_special-price.php');
    /*  include special price section  */

    /*  include new phones section  */
        include ('scripts/_new-phones.php');
    /*  include new phones section  */

?>


<?php
// include footer.php file
include ('footer.php');
?>