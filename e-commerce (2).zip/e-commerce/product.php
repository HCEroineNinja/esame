<?php
// include header.php file
include ('header.php');
?>

<?php

    /*  include products */
    include ('scripts/_products.php');
    /*  include products */

    /*  include top sale section */
    include ('scripts/_top-sale.php');
    /*  include top sale section */

?>

<?php
// include footer.php file
include ('footer.php');
?>

